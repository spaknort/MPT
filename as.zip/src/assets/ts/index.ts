import '../css/index.sass'
import '../css/components/header.sass'
import '../css/components/footer.sass'

import anime from 'animejs/lib/anime.es.js'

anime ({
    targets: '.header',
    translateY: 100,
    duration: 3000,
})

anime ({
    targets: '.line-drawing-demo .lines path',
    strokeDashoffset: [anime.setDashoffset, 0],
    easing: 'easeInOutSine',
    duration: 1500,
    delay: function(el, i) { return i * 250 },
    direction: 'alternate',
    loop: true
})

anime ({
    targets: '.title',
    translateX: 1500,
    duration: 3000,
    delay: 500
})

anime ({
    targets: '.sub-title',
    translateX: 1500,
    duration: 3000,
    delay: 500
    
})

anime ({
    targets: '.offer__buttons',
    translateX: 1500,
    duration: 3000,
    delay: 500
    
})