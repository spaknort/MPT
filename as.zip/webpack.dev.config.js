const
    { merge } = require('webpack-merge')
    baseWebpackConfig = require('./webpack.base.config')

let devWEbpackConfig = merge(baseWebpackConfig, {
    mode: 'development',
    devServer: {
        port: 3000
    }
})

module.exports = new Promise (resolve => {
    resolve(devWEbpackConfig)
})