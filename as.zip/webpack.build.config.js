let
    { merge } = require('webpack-merge'),
    glob = require('glob'),
    ImageMinWebpackPlugin = require('imagemin-webpack-plugin'),
    baseWebpackConfig = require('./webpack.base.config')

let buildWebpackConfig = merge(baseWebpackConfig, {
    mode: 'production',
    plugins: [
        new ImageMinWebpackPlugin ({
            test: /.(png|jpg|svg)$/
        }),
        new ImageMinWebpackPlugin ({
            externalsImages: {
                context: 'src',
                source: glob.sync ('src/iamges/**/*.png'),
                destination: `src/assets/images`,
                fillName: '[path][name].[ext]'
            }
        }),
        new ImageMinWebpackPlugin ({
            jpegtran: {
                progressive: false,
                qualite: '50-70'
            },
            optipng: {
                interlaced: null,
                quality: '50-70',
                optimization: 7
            }
        })
    ]
})

module.exports = new Promise (resolve => {
    resolve (buildWebpackConfig)
})